package com.tinyUrl.tinyUrlGenerate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TinyUrlGenerateApplication {

	public static void main(String[] args) {
		SpringApplication.run(TinyUrlGenerateApplication.class, args);
	}

}
